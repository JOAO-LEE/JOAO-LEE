from src.pre_built.counter import count_ocurrences


def test_counter():
    js_counter = count_ocurrences('data/jobs.csv', 'Javascript')
    py_counter = count_ocurrences('data/jobs.csv', 'Python')

    assert js_counter == 122
    assert py_counter == 1639
    