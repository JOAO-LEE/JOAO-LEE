from typing import Union, List, Dict
from src.insights.jobs import read


def get_max_salary(path: str) -> int:
    """Get the maximum salary of all jobs

    Must call `read`

    Parameters
    ----------
    path : str
        Must be passed to `read`

    Returns
    -------
    int
        The maximum salary paid out of all job opportunities
    """

    # salary_max = 0
    # salary_list = []
    # result_read = read(path)
    # for salary in result_read:
    #     if len(salary["salary_max"]) > 0 and salary["salary_max"] != 
    #         salary_list.append(salary["salary_max"])
    # for salarys_max in salary_list:
    #     if int(salarys_max) > salary_max:
    #         salary_max = int(salarys_max)
    # return int(salary_max)

    result_read = read(path)
    max_salary = 0
    for salary in result_read:
        if (salary['max_salary'] != '' and salary['max_salary'].isdigit()):
            if int(salary["max_salary"]) > max_salary:
                max_salary = int(salary["max_salary"])
    return max_salary


def get_min_salary(path: str) -> int:
    """Get the minimum salary of all jobs

    Must call `read`

    Parameters
    ----------
    path : str
        Must be passed to `read`

    Returns
    -------
    int
        The minimum salary paid out of all job opportunities
    """
    # salary_min = 0
    # salary_list = []
    # result_read = read(path)
    # for salary in result_read:
    #     if len(salary["salary_min"]) > 0 and salary["salary_min"] != 
    #         salary_list.append(salary["salary_min"])
    # salary_min = min(int(salary) for salary in salary_list)
    # return salary_min
    result_read = read(path)
    min_salary = []
    for salary in result_read:
        if (salary["min_salary"] != '' and salary["min_salary"].isdigit()):
            min_salary.append(int(salary["min_salary"]))
    return min(min_salary)


def matches_salary_range(job: Dict, salary: Union[int, str]) -> bool:
    """Checks if a given salary is in the salary range of a given job

    Parameters
    ----------
    job : dict
        The job with `min_salary` and `max_salary` keys
    salary : int
        The salary to check if matches with salary range of the job

    Returns
    -------
    bool
        True if the salary is in the salary range of the job, False otherwise

    Raises
    ------
    ValueError
        If `job["min_salary"]` or `job["max_salary"]` doesn't exists
        If `job["min_salary"]` or `job["max_salary"]` aren't valid integers
        If `job["min_salary"]` is greather than `job["max_salary"]`
        If `salary` isn't a valid integer
    """
    # try:
    #     if not int(job["salary_min"]) and not int(job["salary_max"]):
    #         raise ValueError
    #     if int(job["salary_min"]) > int(job["salary_max"]):
    #         raise ValueError
    #     return int(job["salary_min"]) <= int(salary) <= int(job["sala
    # except Exception:
    #     raise ValueError
    try:
        if int(job["min_salary"]) > int(job["max_salary"]):
            raise ValueError
        if int(job["min_salary"]) <= int(salary) <= int(job["max_salary"]):
            return True
    except (ValueError, TypeError, KeyError):
        raise ValueError
    return False


def filter_by_salary_range(
    jobs: List[dict],
    salary: Union[str, int]
) -> List[Dict]:
    """Filters a list of jobs by salary range

    Parameters
    ----------
    jobs : list
        The jobs to be filtered
    salary : int
        The salary to be used as filter

    Returns
    -------
    list
        Jobs whose salary range contains `salary`
    """
    jobs_filter = []
    list_error = []
    for job in jobs:
        try:
            if(matches_salary_range(job, salary)):
                jobs_filter.append(job)
        except ValueError:
            list_error.append("{job} é invalido")

    return jobs_filter
